document.addEventListener('DOMContentLoaded', () => {
	
// Global Variables are Here//

// HTML references shortened for JS//
const grid = document.querySelector(".grid");
const player = document.querySelector('.player');
const menu = document.getElementById('menu');
const body = document.querySelector('body');
const heading = document.getElementById('heading');
const insts = document.getElementById("inst");
const gameOver = document.getElementById("gameOver");

// References to backdrops//

const background1 = document.querySelector('.background1');
const background2 = document.querySelector('.background2');

// Background Scrolling//
let backgroundMoveSpeed = 0.08;

// Scores System//
const scoresHTML = document.querySelector('.scores');
const scoreHTML = document.getElementById('score');
const highScoreHTML = document.getElementById('highScore');

// Variables for scores//
//localStorage stores the highest score,

let highScore = localStorage.getItem('highScore');
	
//value will change when player gets a higher value

let score = 0;
let scoreSpeed = 0.01;

//scoreSpeed is how fast score increases as the player continues

//Adding player image from JS to CSS//
player.style.backgroundImage = "url(running_1.png)";

// Game Mechanics//

let playerPosition = 15; //Starting Position
let ground = playerPosition;
let statusMenu = true; //Boolean statement says menu is visible
let jumping = false; //When player is jumping
let dead = false; //Game over when player dies

// Variables for Player Movement
let frame = 1; //counts the frame
let jumpHeight = playerPosition;
let jumpTimeInterval = 5; // speed of the jump in ms
let jumpSpeed = 1; //the % per jumpTimeInterval in px
let downSpeed = 0.1;
let gravity = 0.94; // geometric jumps of the player
jumpHeight += 35; // max height player can jump in %

let playerAnimationSpeed = 200; //speed of player's running in ms

// Variables for obstacles
let obstacleSpeed = 1.8;

// Input Checks are Here
//Checks for Space key being pressed
document.addEventListener('keydown', (e)=>{

	// IF not dead AND 'Space' is pressed
	if (!dead && e.code === "Space") {
		// input function called
		input();
		console.log ("Space Pressed")
	}	
	// ELSE dead is true AND 'Space' is pressed
	else if (dead && e.code === "Space"){

		//Reloads the document to start new game
		location.reload();
	}
})

document.addEventListener('touchstart', (e)=>{
	if (dead){
		location.reload();
	}

	else {
		input();
		console.log("Touched");
	}
})

// Menu Transitions are Here

//Declare menuTransitions

function menuTransitions() {
	console.log("Menu switched off"); //Debug Check

	//Hides the menu
	heading.style.visibility = "hidden"; //Tells style to switch

	insts.style.visibility = "hidden";

}

//Main Game Scripts are Here

//Declares input function

function input(e) {
	//IF statusMenu is true, then when 'Space' is pressed
		
	if (statusMenu) {
		statusMenu = false; //menu should be off
		menuTransitions(); //menuTransitions is called
		playerRun(); //player starts running
		console.log("Start"); //Debug Check
		manageObstacles(); // calls function to manage obstacles
		backgroundScroll(); //calls backdrop scrolling function
		addScore(); //calls score operation function

		//Basically this is where most of the game mechanics work out
	}

	//Once menu is gone and player not jumping
	if (!statusMenu && !jumping && !dead) {
		jumping = true; //boolean value set to true
		jump(); //call jump function
		console.log("Jumping")
	}
}

//Script for Player Animation is Here

//Declare playerRun function, this changes the sprite image
function playerRun() {
	setInterval(loopRun, playerAnimationSpeed);

	//Declare loopRun function, loops between the sprite imgs
	//until dead
	function loopRun() {
		
		console.log("Player is Running"); //Debug Check

		//IF frame is 1 AND not jumping AND not dead
		if (frame === 1 && !jumping && !dead) {
			player.style.backgroundImage = "url(running_2.png)";

			//Then change frame to 2
			frame = 2;
		}

		//ELSE IF frame is 2 AND not jumping AND not dead
		else if (frame === 2 && !jumping && !dead) {

			//Change backgroundImage
			player.style.backgroundImage = "url(running_1.png)";

			//and change frame back to 1
			frame = 1;
		}

		//ELSE IF dead is true
		else if (dead) {

			//Change to dead sprite :'(
			player.style.backgroundImage = "url(dead.png)";
		}
	}
}

//Player Jump Script is Here

//declare jump function
function jump() {
	let timer = setInterval( function() { //starts interval for jump

		//IF dead
		if (dead) {
			clearInterval(timer); //player stops jumping
		}

		console.log("UP"); //Debug Check

		//Player goes up
			
		//Change background Image to jumping
		player.style.backgroundImage = "url(jump_1.png)";

		//Jump calculations
		jumpSpeed = 1
		playerPosition += jumpSpeed;
		jumpSpeed = jumpSpeed * gravity;
		if (jumpSpeed <= 0.17) {jumpSpeed = 0.2;}

		//Tells CSS that player position changed

		player.style.bottom = playerPosition + '%';

			//IF player reaches max height
			if (playerPosition >= jumpHeight) {

				console.log("DOWN"); //Debug Check

				clearInterval(timer); //stop jumping

				let downTimer = setInterval(function(){ //start down interval

					//Falling Calculations
					playerPosition -= downSpeed;
					downSpeed = downSpeed + (downSpeed*0.08);

					//Tell CSS new falling position
					player.style.bottom = playerPosition + '%';

					//change background image
					player.style.backgroundImage = "url(jump_2.png)";

					//When player reach ground position
					if (playerPosition <= ground) {

						console.log("Landed");

						clearInterval(downTimer); //stop falling

						//Reset the variables, values will change when player jumps again
						jumpSpeed = 1;
						downSpeed = 0.3;
						jumping = false;
						playerPosition = ground;
						player.style.bottom = playerPosition + '%';
					}
				}, jumpTimeInterval)
			}
	}, jumpTimeInterval)
}

// Manage Obstacles script is Here

//Declare manageObstacles
function manageObstacles() {

	//Obstacles should be called randomly
	randomCall(); //Call randomCall function
}

//Declare randomTime variable
var randomTime;

//declare changeTime function
function changeTime() {
		
	randomTime = Math.floor(Math.random() * (3000 - 1000) + 1000); 
	//Line above generates a number using that calculation
}

//Declare randomCall function
function randomCall() {
	
	console.log("Random call at " + randomTime + " ms"); //Debug Check

	//Call changeTime function
	changeTime();

	//This function uses the random variables for the obstacles to appear
	setTimeout(randomCall, randomTime);

	//call generateObstacle function
	generateObstacle();
}

//Generating and Moving Obstacles

//Declare generateObstacle
function generateObstacle() {

	console.log("Obstacle generated"); //Debug Check

	//Initialize obstacle position
	let obstacleXPosition = 1920;

	//Obstacle generation
	const obstacle = document.createElement('div');

	//Because obstacle doesn't exist in the main html doc,
	//it's created here in JS instead

	//IF not dead then add "obstacle" from CSS to the created div above
	if (!dead) {obstacle.classList.add('obstacle');}

	grid.appendChild(obstacle); //add the obstacle div to the grid HTML element
	obstacle.style.left = obstacleXPosition + "px"; //assigns the position to CSS

	//Obstacle moves
	let moveObstacle = setInterval(()=> { //create interval

		//IF not dead then
		if (!dead) {
			obstacleXPosition -= obstacleSpeed;

			//As it moves the new postion is assigned to CSS
			obstacle.style.left = obstacleXPosition + 'px';
		}

		//Remove obstacle when moves off screen

		if (obstacleXPosition <= -50) {
			
			obstacle.classList.remove('obstacle'); //removes the class attribute
			try{grid.removeChild(obstacle)} //removes the div child
			catch(error){} //this handles the possible error above to keep deleting
		}

		//Detect collision with player

		//IF obstacleXPosition enters within range
		if (obstacleXPosition > 5 && obstacleXPosition <45 && playerPosition < 35) {
			
			console.log("Collision!") //Debug Check
			clearInterval(moveObstacle); //stop obstacle from moving
			GameOver(); //Call GameOver function
		}

	}, 1); //end of interval
}

//Background scrolling script is Here

//Declare backgroundScroll function
function backgroundScroll() {

	let background1Pos = 0; //Positioned on screen
	let background2Pos = 100; //Positioned off screen

	setInterval(()=> {

		//IF not dead
		if (!dead) {

			//Change the values of the variables above to get it moving
			background1Pos = background1Pos - backgroundMoveSpeed;

			//Send that info to CSS
			background1.style.left = background1Pos + '%';

			background2Pos = background2Pos - backgroundMoveSpeed;

			background2.style.left = background2Pos + '%';
		}

		//Reset background divs when off screen

		//IF background moves off screen
		if (background1Pos <= -99) {

			//then reset it to original value
			background1Pos = 100;
		}

		if (background2Pos <=-99) {

			background2Pos = 100;
		}
	}, 1) //End of interval
}

		
// Score system srcipt is Here

//Declare addScore function
function addScore() {
	
	//initialize interval for scores
	setInterval( () => {

		//IF not dead
		if (!dead) {

			score += 1; //score increases by 1

			//IF score is greater than highScore
			if (score > highScore) {
				highScore = score; //sets the new high value
			}

			scoreHTML.innerHTML = score; //writes score value in HTML

			highScoreHTML.innerHTML = "High Score: " + highScore; //writes high score in HTML

			//IF score can be divided by 1000 with no remainder, increase difficulty
			if (score%1000 == 0) {
				backgroundMoveSpeed += 0.01; //background speed increases

				obstacleSpeed += 0.3; //obstacle speed also increases
			}
		}

		//IF dead
		if (dead) {

			//then store highScore to localStorage
			localStorage.setItem("highScore", highScore);
		}
	}, scoreSpeed)
}

//Game Over Script is Here

//Declare GameOver function
function GameOver() {
			
	gameOver.style.visibility = "visible"; //tells CSS to set webpage appearance to game over
	body.style.backgroundColor = "red"; //change background color
	dead = true; //set boolean value to true
	}

})